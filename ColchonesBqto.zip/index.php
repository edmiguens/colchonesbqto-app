<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Estado del servidor</title>
</head>
<body>
  <h1>✅ Apache está funcionando correctamente</h1>
</body>
</html>