<?php
function obtenerClientes() {
    return [
        ["nombre" => "Ferretería Central", "deuda" => 1520.75],
        ["nombre" => "Colchones Lara C.A.", "deuda" => 1320.00],
        ["nombre" => "Distribuidora El Trigal", "deuda" => 1098.50],
        ["nombre" => "Tienda Hogar Feliz", "deuda" => 875.10],
        ["nombre" => "Comercial El Orbe", "deuda" => 745.00],
        ["nombre" => "DecoMuebles VIP", "deuda" => 650.25]
    ];
}