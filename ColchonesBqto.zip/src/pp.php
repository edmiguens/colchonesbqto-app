echo "<pre>";
echo "URL generada:\n" . $OAuth2LoginHelper->getAuthorizationCodeURL();
echo "</pre>";
exit;