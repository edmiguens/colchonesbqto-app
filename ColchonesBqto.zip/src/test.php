<?php
echo file_exists("clientes.php") ? "✅ clientes.php OK<br>" : "❌ Falta<br>";
echo file_exists("token.json") ? "✅ token.json OK<br>" : "❌ Falta<br>";
echo file_exists("Conexion2.php") ? "✅ Conexion2.php OK<br>" : "❌ Falta<br>";
?>